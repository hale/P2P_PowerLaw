/**
 * Contains the classes that define agents in the simulation, including the
 * two types of peer and other agents like the Runner and the Host Cache.
 */
package agents;
