/**
 * Groups the Ontology related files, such as the types of messages,
 * the vocabulary, and the ontology definition itself.
 */
package ontology;