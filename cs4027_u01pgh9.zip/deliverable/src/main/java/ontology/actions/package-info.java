/**
 * Actions can be thought of as formal Message definitions that are sent between agents in the network.
 */
package ontology.actions;