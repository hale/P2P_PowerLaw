/**
 * Functionality for agents is composed of combinations of several Behaviours.
 */
package behaviours;